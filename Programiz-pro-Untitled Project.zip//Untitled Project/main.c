//print odd numbers between 1to 25
#include<stdio.h>

int main()
{
    for(int i=1;i<=25;i+=2)
{
    printf("%d/n",i);
}
return 0;
}